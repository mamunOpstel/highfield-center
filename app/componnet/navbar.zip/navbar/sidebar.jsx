import { faAngleDown, faXmark } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import styles from "./sidebar.module.css";

function Sidebar({ switchFunc }) {
  function switchMenu() {
    switchFunc();
  }

  let navUl = [
    "HOME",
    // { "ABOUT US": ["Our Experts", "Our Success"] },
    "SERVICES",
    "STUDY DESTINATION ",
    "BLOG",
    "CONTANT",
  ];

  return (
    <div>
      <FontAwesomeIcon
        icon={faXmark}
        className=" w-[20px] h-[20px] p-2 cursor-pointer float-right clear-both m-8 text-orange-500 border-2 border-orange-500 rounded-md shadow-lg "
        onClick={switchMenu}
      />
      {/* Menu starts here */}
      <ul>
        {navUl.map((item) => {
          <li>{item}</li>;
        })}
      </ul>
      {/* Menu ends here */}
    </div>
  );
}

export default Sidebar;
